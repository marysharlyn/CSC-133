package com.mycompany.a2.interfaces;

public interface Isteerable {
	
	public void moveLeft();
	
	public void moveRight();
}
